/* Technik Soused: reviews and ranking DEMO. NOT trusted backend. */
(function(root){'use strict';
const MINUTE=60000,REVIEW_MS=60*MINUTE,BOOST_MS=15*MINUTE;
const BOOST_DAY_NAMES=['Neděle','Pondělí','Úterý','Středa','Čtvrtek','Pátek','Sobota'];
function boostConfig(db){
 if(!db.boostTiming||!Array.isArray(db.boostTiming.days)||db.boostTiming.days.length!==7)db.boostTiming={days:[15,15,15,15,15,15,15],windows:[]};
 if(!Array.isArray(db.boostTiming.windows))db.boostTiming.windows=[];
 return db.boostTiming;
}
function boostMinutesAt(db,at=Date.now()){
 const cfg=boostConfig(db);
 const format=new Intl.DateTimeFormat('en-US',{timeZone:'Europe/Prague',weekday:'short',hour:'2-digit',minute:'2-digit',hourCycle:'h23'});
 const parts=Object.fromEntries(format.formatToParts(new Date(at)).map(x=>[x.type,x.value]));
 const day={Sun:0,Mon:1,Tue:2,Wed:3,Thu:4,Fri:5,Sat:6}[parts.weekday];
 const clock=Number(parts.hour)*60+Number(parts.minute);
 const active=cfg.windows.find(w=>Number(w.day)===day&&/^\d{2}:\d{2}$/.test(w.from||'')&&/^\d{2}:\d{2}$/.test(w.to||'')&&clock>=Number(w.from.slice(0,2))*60+Number(w.from.slice(3,5))&&clock<Number(w.to.slice(0,2))*60+Number(w.to.slice(3,5)));
 const value=active?Number(active.minutes):Number(cfg.days[day]);
 return Number.isInteger(value)&&value>=1&&value<=1440?value:15;
}

const REGIONS={'Praha':['Praha'],'Středočeský kraj':['Benešov','Beroun','Kladno','Kolín','Kutná Hora','Mladá Boleslav','Nymburk','Příbram','Rakovník','Říčany','Čáslav','Brandýs nad Labem-Stará Boleslav'],'Jihočeský kraj':['České Budějovice','Český Krumlov','Jindřichův Hradec','Písek','Prachatice','Strakonice','Tábor'],'Plzeňský kraj':['Plzeň','Domažlice','Klatovy','Rokycany','Tachov'],'Karlovarský kraj':['Karlovy Vary','Cheb','Sokolov','Aš','Mariánské Lázně'],'Ústecký kraj':['Ústí nad Labem','Děčín','Chomutov','Litoměřice','Louny','Most','Teplice'],'Liberecký kraj':['Liberec','Česká Lípa','Jablonec nad Nisou','Semily','Turnov'],'Královéhradecký kraj':['Hradec Králové','Jičín','Náchod','Trutnov'],'Pardubický kraj':['Pardubice','Chrudim','Svitavy','Ústí nad Orlicí'],'Kraj Vysočina':['Jihlava','Havlíčkův Brod','Pelhřimov','Třebíč','Žďár nad Sázavou'],'Jihomoravský kraj':['Brno','Blansko','Břeclav','Hodonín','Vyškov','Znojmo'],'Olomoucký kraj':['Olomouc','Jeseník','Prostějov','Přerov','Šumperk'],'Zlínský kraj':['Zlín','Kroměříž','Uherské Hradiště','Vsetín'],'Moravskoslezský kraj':['Ostrava','Bruntál','Frýdek-Místek','Karviná','Nový Jičín','Opava','Třinec']};
const norm=x=>String(x||'').toLocaleLowerCase('cs').normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim();
const key=(a,b)=>norm(a)+'|'+norm(b);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function init(db){db.reviewTickets??=[];db.customerReviews??=[];db.adminReviewNotes??=[];db.reviewNotices??=[];db.rankPins??={};db.rankBoosts??={};db.rankLog??=[];db.globalDefaultPin??=null;
 if(!Array.isArray(db.rankBoostHistory)){db.rankBoostHistory=Object.values(db.rankBoosts).filter(x=>x&&x.techId&&x.city&&x.appliance).map((x,i)=>({...x,id:'legacy-'+i}));}
 db.rankPositionNotices??=[];db.rankPositionSnapshots??={};return db;}
function randomHex(bytes){const a=new Uint8Array(bytes);if(root.crypto?.getRandomValues)root.crypto.getRandomValues(a);else for(let i=0;i<a.length;i++)a[i]=Math.floor(Math.random()*256);return Array.from(a,x=>x.toString(16).padStart(2,'0')).join('');}
function code(){const a=new Uint32Array(1);if(root.crypto?.getRandomValues)root.crypto.getRandomValues(a);else a[0]=Math.floor(Math.random()*4294967296);return String(a[0]%90000000+10000000);}
function region(city){return Object.keys(REGIONS).find(r=>(REGIONS[r]||[]).some(c=>norm(c)===norm(city)))||'';}
function allowed(t,city,appliance){return !!t&&!t.blocked&&!(t.blockedCities||[]).includes(city)&&(!city||(t.cities||[]).some(c=>norm(c)===norm(city)))&&(!appliance||(t.appliances||[]).some(x=>norm(x)===norm(appliance)));}
function createAfterClose(db,order,previous){init(db);if(previous==='Dokončená'||order.status!=='Dokončená'||!order.assigned)return null;
 const already=db.reviewTickets.find(x=>String(x.orderId)===String(order.id));if(already)return already;
 const t=db.technicians.find(x=>x.id===order.assigned);if(!t)return null;
 const created=Date.now(),r={id:randomHex(12),token:randomHex(18),code:code(),orderId:order.id,techId:t.id,techName:t.name,created,expires:created+REVIEW_MS,used:false};
 db.reviewTickets.push(r);db.reviewNotices.push({id:r.id,techId:t.id,orderId:order.id,created,read:false});db.rankLog.push({at:created,action:'review_token_issued',orderId:order.id,techId:t.id});return r;
}
function ticketStatus(x,time=Date.now()){return x.used?'použit':x.expires<=time?'vypršel':'aktivní';}
function url(kind,token){const loc=root.location||{href:'https://example.invalid/'};const isPlumber=kind==='instalateri';const src='hodnoceni.html';let link=new URL(src,loc.href);link.searchParams.set('d',isPlumber?'instalateri':'technici');link.searchParams.set('t',token);return link.href;}
function submit(db,token,codeInput,data){init(db);const t=db.reviewTickets.find(x=>x.token===token);if(!t)return {ok:false,error:'Odkaz na hodnocení není platný.'};if(t.used)return {ok:false,error:'Kód již byl použit.'};if(t.expires<=Date.now())return {ok:false,error:'Platnost kódu 60 minut již vypršela.'};if(!/^[0-9]{8}$/.test(String(codeInput))||t.code!==String(codeInput))return {ok:false,error:'Nesprávný jednorázový kód.'};const order=db.orders.find(o=>String(o.id)===String(t.orderId));if(!order||order.status!=='Dokončená'||order.assigned!==t.techId)return {ok:false,error:'Zakázka není uzavřena u tohoto technika.'};if(db.customerReviews.some(x=>String(x.orderId)===String(t.orderId)))return {ok:false,error:'K této zakázce již byla recenze odeslána.'};const rating=Number(data.rating),text=String(data.text||'').trim(),name=String(data.name||'').trim();if(!Number.isInteger(rating)||rating<1||rating>5||text.length<15||name.length<2)return {ok:false,error:'Vyplňte jméno, hodnocení 1–5 a alespoň 15 znaků textu.'};
 const r={id:randomHex(12),orderId:t.orderId,techId:t.techId,rating,name:name.slice(0,80),text:text.slice(0,1200),status:'pending',source:'customer_order_code',at:Date.now()};db.customerReviews.push(r);t.used=true;t.usedAt=Date.now();db.rankLog.push({at:Date.now(),action:'review_submitted',orderId:t.orderId,techId:t.techId});return {ok:true,review:r};}
function reviews(db,techId,onlyPublished=true){init(db);return db.customerReviews.filter(r=>r.techId===techId&&(!onlyPublished||r.status==='published'));}
function rating(db,techId){const arr=reviews(db,techId);return {count:arr.length,avg:arr.length?arr.reduce((sum,r)=>sum+Number(r.rating),0)/arr.length:0};}
function pin(db,reg,appliance,techId){init(db);if(!reg||!appliance)throw Error('Vyberte kraj a specializaci.');
 const tech=techId?db.technicians.find(t=>String(t.id)===String(techId)):null;
 if(techId&&(!tech||tech.blocked||!(tech.appliances||[]).some(x=>norm(x)===norm(appliance))))throw Error('Technik nemá vybranou specializaci nebo je blokován.');
 if(techId&&!(tech.cities||[]).some(c=>norm(region(c))===norm(reg)))throw Error('Technik nepracuje v uvedeném kraji.');
 reconcileAll(db);
 if(!techId){delete db.rankPins[key(reg,appliance)];}
 else {db.rankPins[key(reg,appliance)]={techId,region:reg,appliance,at:Date.now()};db.rankLog.push({at:Date.now(),action:'pin',techId,region:reg,appliance});}
 reconcileAll(db);
}
function setGlobalDefaultPin(db,techId){
 init(db);
 const t=techId?db.technicians.find(x=>String(x.id)===String(techId)):null;
 if(techId&&(!t||t.blocked))throw Error('Vybraný technik neexistuje nebo je zablokovaný.');
 // Record current positions in every professional category before changing the pin.
 reconcileAll(db);
 if(!techId){db.globalDefaultPin=null;db.rankLog.push({at:Date.now(),action:'global_pin_disabled'});}
 else {db.globalDefaultPin={techId:String(t.id),at:Date.now()};
  db.rankLog.push({at:Date.now(),action:'global_pin_changed',techId:String(t.id)});}
 reconcileAll(db);
 return db.globalDefaultPin;
}
// An ordered history is kept after a paid attempt expires. Expiry ends first-place priority,
// but does not erase the technician's recency relative to older paid attempts.
function ranked(db,city,appliance,regOverride,at=Date.now()){
 init(db);
 const all=db.technicians.filter(t=>allowed(t,city,appliance));
 if(!city||!appliance)return all;
 const k=key(city,appliance), byId=new Map(all.map(t=>[String(t.id),t]));
 const newest=new Map();
 for(const b of db.rankBoostHistory){if(!b||key(b.city,b.appliance)!==k||Number(b.at)>at||!byId.has(String(b.techId)))continue;
  const id=String(b.techId), old=newest.get(id);
  if(!old||Number(b.at)>Number(old.at)||(Number(b.at)===Number(old.at)&&Number(b.id||0)>Number(old.id||0)))newest.set(id,b);
 }
 const history=[...newest.values()].sort((a,b)=>Number(b.at)-Number(a.at)||String(b.id).localeCompare(String(a.id)));
 const active=history.filter(x=>Number(x.until)>at);
 const inOrder=[],seen=new Set();
 function add(id){const t=byId.get(String(id));if(t&&!seen.has(String(t.id))){seen.add(String(t.id));inOrder.push(t)}}
 // The newest still-active genuine attempt wins immediately, regardless of earlier promotions.
 if(active.length)add(active[0].techId);
 // Without an active boost, the administrator's saved default/fallback returns to first place.
 let fallback=db.globalDefaultPin?.techId;
 const p=db.rankPins[key(regOverride||region(city),appliance)];
 if(!byId.has(String(fallback))&&p)fallback=p.techId;
 if(!active.length&&fallback)add(fallback);
 // The latest used attempts remain ahead of older ones, hence positions 2, 3, 4... .
 for(const b of history)add(b.techId);
 if(active.length&&fallback)add(fallback);
 // If no default is available, one ordinary unpromoted profile occupies the first slot
 // when paid priority expires, so the latest formerly promoted profile moves to second.
 if(!active.length&&!fallback&&history.length){
  const fresh=all.find(t=>!newest.has(String(t.id)));
  if(fresh){const i=inOrder.findIndex(t=>String(t.id)===String(fresh.id));if(i<0){inOrder.unshift(fresh);seen.add(String(fresh.id));}else{inOrder.splice(i,1);inOrder.unshift(fresh)}}
 }
 for(const t of all)add(t.id);
 return inOrder;
}
function leader(db,city,appliance,regOverride){
 const rows=ranked(db,city,appliance,regOverride);
 if(!rows.length||!city||!appliance)return null;
 const top=rows[0],at=Date.now(),k=key(city,appliance);
 const live=db.rankBoostHistory.filter(b=>b&&key(b.city,b.appliance)===k&&String(b.techId)===String(top.id)&&b.at<=at&&b.until>at).sort((a,b)=>b.at-a.at);
 const active=live[0];
 if(active)return {tech:top,kind:'paid',until:active.until,label:'Sponzorovaná pozice'};
 if(String(db.globalDefaultPin?.techId||'')===String(top.id)||String(db.rankPins[key(regOverride||region(city),appliance)]?.techId||'')===String(top.id))
  return {tech:top,kind:'pinned',label:'Sponzorovaná pozice'};
 return null;
}
function reconcile(db,city,appliance,at=Date.now()){
 init(db);if(!city||!appliance)return false;
 const k=key(city,appliance),list=ranked(db,city,appliance,undefined,at);
 const positions=Object.fromEntries(list.map((t,i)=>[String(t.id),i+1]));
 const before=db.rankPositionSnapshots[k];
 let changed=false;
 if(before){
  for(const [id,newPlace] of Object.entries(positions)){
   const oldPlace=Number(before[id]);
   // Notify every affected technician for any downward movement, including multi-place drops.
   // Newly added technicians have no previous place, so no false notification is created.
   if(Number.isInteger(oldPlace)&&oldPlace>0&&newPlace>oldPlace){
    const msg={id:'rank-down-'+at+'-'+id+'-'+db.rankPositionNotices.length,techId:id,
     city,appliance,fromPosition:oldPlace,toPosition:newPlace,position:newPlace,
     at,read:false,kind:'position_dropped'};
    db.rankPositionNotices.push(msg);
    db.rankLog.push({at,action:'position_dropped',techId:id,city,appliance,fromPosition:oldPlace,toPosition:newPlace});
    changed=true;
   }
  }
 }
 if(JSON.stringify(before)!==JSON.stringify(positions)){db.rankPositionSnapshots[k]=positions;changed=true;}
 // Retain every unread alert for every technician. Only older *read* alerts may be pruned.
 const readCount=db.rankPositionNotices.filter(a=>a.read).length;
 if(readCount>500){let toDrop=readCount-500;db.rankPositionNotices=db.rankPositionNotices.filter(a=>!(a.read&&toDrop-->0));changed=true;}
 return changed;
}
function reconcileAll(db,at=Date.now()){
 init(db);const pairs=new Map();
 function include(city,appliance){if(city&&appliance)pairs.set(key(city,appliance),[city,appliance]);}
 // Scan ALL active professionals and every matching city + specialty, even when nobody
 // has bought a boost. This establishes a baseline for all catalog positions.
 for(const t of db.technicians||[]){if(!t||t.blocked)continue;
  for(const city of t.cities||[])for(const appliance of t.appliances||[]){
   if(allowed(t,city,appliance))include(city,appliance);
  }
 }
 for(const b of db.rankBoostHistory)if(b)include(b.city,b.appliance);
 for(const b of Object.values(db.rankBoosts))if(b)include(b.city,b.appliance);
 // Keep old snapshots after a specialization has been removed. They produce no false
 // notification for absent technicians because reconcile only checks present ids.
 for(const k of Object.keys(db.rankPositionSnapshots))if(!pairs.has(k)){
  const b=db.rankBoostHistory.find(x=>key(x.city,x.appliance)===k);
  if(b)include(b.city,b.appliance);
 }
 let changed=false;
 for(const [city,appliance] of pairs.values())changed=reconcile(db,city,appliance,at)||changed;
 return changed;
}
function positionAlerts(db,techId){init(db);return db.rankPositionNotices.filter(x=>String(x.techId)===String(techId)).slice().reverse();}
function markPositionAlerts(db,techId){init(db);let n=0;for(const a of db.rankPositionNotices)if(String(a.techId)===String(techId)&&!a.read){a.read=true;n++}return n;}
function boosted(db,techId,city,appliance){
 init(db);const reg=region(city),k=key(city,appliance);
 if(!reg||!city||!appliance)throw Error('Zvolte město a specializaci.');
 const t=db.technicians.find(x=>String(x.id)===String(techId));
 if(!allowed(t,city,appliance))throw Error('Město nebo specializace není v profilu, případně je účet blokován.');
 if(!Number.isFinite(t.attempts)||t.attempts<1)throw Error('Nemáte dostatek pokusů.');
 const at=Date.now(),minutes=boostMinutesAt(db,at);
 reconcileAll(db,at);
 reconcile(db,city,appliance,at);
 // Save the complete history; do not erase the previous technician on a new attempt.
 const item={id:'paid-'+at+'-'+db.rankBoostHistory.length,techId:String(t.id),city,region:reg,appliance,at,until:at+minutes*MINUTE,minutes};
 t.attempts-=1;db.rankBoostHistory.push(item);db.rankBoosts[k]=item;
 db.rankLog.push({at,action:'boost_activated',techId:String(t.id),city,appliance,minutes});
 reconcile(db,city,appliance,at);
 return item;
}
root.TSRR={init,REGIONS,reviewMs:REVIEW_MS,boostMs:BOOST_MS,boostConfig,boostMinutesAt,boostDays:BOOST_DAY_NAMES,setGlobalDefaultPin,region,allowed,ranked,reconcile,reconcileAll,positionAlerts,markPositionAlerts,createAfterClose,ticketStatus,url,submit,reviews,rating,pin,boosted,leader,esc,key};
})(window);
