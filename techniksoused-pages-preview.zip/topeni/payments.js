/* Technik Soused: offline demo QR bank transfer, no financial verification.
   Real production must use verified server sessions, database, idempotent confirmation, role permissions. */
(function(){'use strict';
const CFG='ts_payment_bank_config_v1';
const emptyCfg={bank:'',account:'',iban:'',owner:'',qr:'',note:'',version:1};
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=n=>Number(n||0).toLocaleString('cs-CZ',{maximumFractionDigits:2})+' Kč';
function cfg(){try{const c={...emptyCfg,...JSON.parse(localStorage.getItem(CFG)||'{}')};if(c.qr&&!/^data:image\/(png|jpeg|webp);base64,[a-z0-9+/=]+$/i.test(c.qr))c.qr='';return c}catch{return {...emptyCfg}}}
function isBlock(t,city){return Boolean(t?.blocked||(city&&(t?.blockedCities||[]).includes(city)))}
function init(db){db.qrPayments||=[];db.qrAudit||=[];return db}
function audit(db,action,techId,details){db.qrAudit.unshift({at:Date.now(),action,techId,details});db.qrAudit=db.qrAudit.slice(0,160)}
function warn(txt){if(typeof toast==='function')toast(txt);else alert(txt)}
function saved(db,event){save(db,event||{type:'payment_demo_change'});if(typeof render==='function')render()}
function getPayment(db,id){return (db.qrPayments||[]).find(p=>p.id===id)}
function isAdmin(){return document.body.dataset.role==='admin'}
function own(db){return getTech(db,window.TS_AUTH?.techId|| (typeof techId!=='undefined'?techId:''))}
function masterInfo(t){return {masterId:String(t.id),masterName:String(t.name||'').trim()}}
function normName(s){return String(s||'').normalize('NFC').trim().replace(/\s+/g,' ').toLocaleLowerCase('cs')}
function validateIdentity(t,field){
 const v=String(document.getElementById(field)?.value||'').trim();
 if(!v)return warn('Zadejte celé jméno nebo své ID technika.'),null;
 if(v===String(t.id)||normName(v)===normName(t.name))return v;
 warn('Zadané jméno nebo ID se neshoduje s vaším profilem. Použijte přesné údaje z účtu.');return null;
}
function identityInput(t,id){return `<label class="field">Jméno a příjmení NEBO osobní ID technika (povinné)<input id="${id}" autocomplete="name" maxlength="100" placeholder="Jméno a příjmení / ID"></label><p class="muted">Váš účet: <strong>${esc(t.name||'—')}</strong> · ID: <strong>${esc(t.id)}</strong>. Platba bude přiřazena k tomuto účtu, ne podle jména odesílatele převodu.</p>`}
function unreadCount(db){return [...(db.qrPayments||[]),...(db.planRequests||[]),...(db.boostRequests||[])].filter(x=>!x.adminSeenAt && (x.type || x.status==='Čeká na schválení')).length}
function markRead(){if(!isAdmin())return;const db=init(load());let changes=0;for(const r of [...db.qrPayments,...(db.planRequests||[]),...(db.boostRequests||[])])if(!r.adminSeenAt){r.adminSeenAt=Date.now();changes++}if(changes)saved(db,{type:'purchase_notifications_seen'});else refresh()}
function adminNoticeList(db){const requests=[...(db.planRequests||[]).map(p=>({...p,kind:'Tarifní žádost'})),...(db.boostRequests||[]).map(p=>({...p,kind:'Žádost o pokusy'}))].filter(p=>p.status==='Čeká na schválení');return requests.length?`<details><summary>Další žádosti mimo QR (${requests.length})</summary>${requests.slice().reverse().map(p=>{const t=getTech(db,p.techId);return `<div class="item"><strong>${esc(p.kind)} · ${esc(p.tier||p.qty||'')}</strong><p>Jméno a příjmení: <strong>${esc(p.masterName||t?.name||'—')}</strong> · ID technika: <strong>${esc(p.masterId||p.techId)}</strong></p><p>Potvrzeno mistrem: ${esc(p.payerEntry||'nevyplněno ve starší žádosti')} · ${esc(p.city)} · ${fmt(p.amount)}</p><p>Číslo žádosti: ${esc(p.id)} · ${esc(p.status)}</p></div>`}).join('')}</details>`:''}
function missing(){return '<div class="notice warning">Nejdříve musí administrátor vložit bankovní účet a platební QR kód. Bez těchto údajů nelze vystavit platební pokyny.</div>'}
function options(items){return items.map(s=>`<option value="${esc(s)}">${esc(s)}</option>`).join('')}
function renderWorker(db,t){init(db);const c=cfg(),ready=!!(c.account.trim()&&c.qr);
const payments=db.qrPayments.filter(p=>p.techId===t.id).slice().reverse();
const cities=t.cities||[];
return `<div class="panel"><h2>💳 Platby a fakturace</h2><p class="sub">Bankovní převod pomocí QR kódu. Tarif pro každé město zvlášť; 1 pokus slouží pro posun v jediném městě.</p>
${isBlock(t)?'<div class="notice warning">Váš účet nebo některé město je zablokováno. Platba blokaci sama nezruší.</div>':''}
${!ready?missing():`<div class="notice">Údaje přijímá ${esc(c.owner||'provozovatel platformy')} · ${esc(c.bank||'bankovní převod')}. Po zaplacení sdělte variabilní symbol. Platba se ověřuje administrátorem proti bankovnímu výpisu, neautomaticky.</div>`}
<div class="twocol"><div class="item"><h3>Členství Základní / Standard / Premium</h3>
<label class="field">Město z profilu<select id="pay-city" onchange="TSPay.updatePlanChoice()">${options(cities)}</select></label>
<label class="field">Tarif<select id="pay-tier" onchange="TSPay.updatePlanChoice()"><option value="Základní">Základní — zdarma (0 Kč)</option><option value="Standard" selected>Standard — placený</option><option value="Premium">Premium — placený</option></select></label>
<label class="field">Kategorie služeb<select id="pay-cat">${options(t.appliances||[])}</select></label>
<label class="field">Doba<select id="pay-days">${PERIODS.map(d=>`<option value="${d}">${d} dní</option>`).join('')}</select></label>
${identityInput(t,'pay-identity')}
<button class="btn" id="pay-plan-button" ${!ready||!cities.length?'disabled':''} onclick="TSPay.createPlan()">Vystavit QR pokyny k platbě</button><p class="muted" id="pay-plan-note">Standard a Premium: placené tarify, QR pokyny po nastavení účtu.</p></div>
<div class="item"><h3>Koupit pokusy</h3><p class="muted">Pokusy mají společný zůstatek, nákup je přiřazen k vybranému městu.</p>
<label class="field">Město<select id="pay-boost-city">${options(cities)}</select></label>
<label class="field">Počet pokusů<input id="pay-qty" type="number" min="1" max="1000" value="10"></label>
${identityInput(t,'pay-boost-identity')}
<button class="btn alt" ${!ready||!cities.length?'disabled':''} onclick="TSPay.createBoost()">Vystavit QR pokyny k platbě</button></div></div>
<h3>Moje platby</h3>${payments.length?payments.map(p=>paymentCard(p,c)).join(''):'<div class="empty">Dosud žádné QR platby. Vystavte pokyny výše.</div>'}
<p class="fake-note">DEMO: QR obrázek pochází od banky. Váš bankovní QR kód může obsahovat jen číslo účtu — správnou částku a variabilní symbol vždy ověřte před potvrzením v bankovní aplikaci. Potvrzení platby se nesmí řídit kliknutím technika.</p></div>`}
function paymentCard(p,c){const stale=p.status==='Čeká na úhradu' && (p.account!==c.account || p.qr!==c.qr);return `<div class="item" id="qr-order-${esc(p.id)}"><div class="itemhead"><div><strong>${p.type==='plan'?`${esc(p.tier)} · ${esc(p.city)} · ${Number(p.days)} dní`:`${Number(p.qty)} pokusů · ${esc(p.city)}`}</strong><p>${new Date(p.created).toLocaleString('cs-CZ')} · číslo žádosti ${esc(p.id)}</p></div><span class="tag ${p.status==='Aktivováno'?'ok':p.status.includes('Zamítnuto')?'red':'gold'}">${esc(p.status)}</span></div>
<p>Plátce: <strong>${esc(p.masterName||'—')}</strong> · ID technika: <strong>${esc(p.masterId||p.techId)}</strong> · uvedený údaj: <strong>${esc(p.payerEntry||'—')}</strong></p>
<div class="grid"><div><p><strong>Částka: ${fmt(p.amount)}</strong></p><p>Účet: <strong>${esc(p.account||c.account||'—')}</strong></p><p>IBAN: ${esc(p.iban||'—')}</p><p>Variabilní symbol: <strong>${esc(p.variableSymbol)}</strong></p><p class="muted">Příjemce: ${esc(p.owner||'—')}</p><p><strong>Zpráva pro příjemce:</strong> ${esc(p.paymentMessage||'TS '+(p.masterId||p.techId)+' / '+p.id)}</p><p class="muted">VS a částku vyplňte v bankovní aplikaci, i když jsou údaje v QR.</p>${stale?'<p class="notice warning">Neplaťte na původní účet. Starou žádost lze zrušit u administrátora.</p>':`<div class="actions"><button class="btn ghost" onclick="TSPay.copy('${esc(p.variableSymbol)}')">Kopírovat VS</button><button class="btn ghost" onclick="TSPay.copy('${esc(p.account)}')">Kopírovat účet</button><button class="btn ghost" onclick="TSPay.copy('${Number(p.amount).toFixed(2)}')">Kopírovat částku</button></div>`}</div>
<div class="qr-wrap">${stale?'<p class="notice warning">Platební údaje se změnily. Tento QR již nepoužívejte. Vystavte si nové platební pokyny.</p>':p.qr?`<img class="qr-img" src="${p.qr}" alt="QR platby bankovním převodem">`:'<p class="muted">QR nebyl v době žádosti nastaven</p>'}</div></div>
${p.status==='Čeká na úhradu'&&!stale?`<p class="notice warning">Po zaplacení kontaktujte provozovatele. Platba se ověří dle bankovního výpisu. Doklad o zadání převodu není důkaz připsání peněz.</p>`:''}</div>`}
function generateId(db){let x;do{x='QR-'+String(Date.now())+'-'+Math.floor(Math.random()*1000).toString().padStart(3,'0')}while(db.qrPayments.some(p=>p.id===x));return x}
function vs(db){let x;do{x=String(Date.now()%10000000000).padStart(10,'0')}while(db.qrPayments.some(p=>p.variableSymbol===x));return x}
function updatePlanChoice(){const tier=document.getElementById('pay-tier')?.value,free=tier==='Základní',button=document.getElementById('pay-plan-button'),days=document.getElementById('pay-days'),cat=document.getElementById('pay-cat'),note=document.getElementById('pay-plan-note'),c=cfg(),ready=!!(c.account.trim()&&c.qr);if(days)days.disabled=free;if(cat)cat.disabled=free;if(button){button.disabled=!document.getElementById('pay-city')?.value||(!free&&!ready);button.textContent=free?'Aktivovat Základní zdarma':'Vystavit QR pokyny k platbě'}if(note)note.textContent=free?'Základní je zdarma, bez platby a bez časového omezení. Nepřináší interní poptávky.':'Standard a Premium: placené tarify, aktivace po ověření platby.'}
function createPlan(){if(isAdmin())return;const db=init(load()),t=own(db),c=cfg();if(!t)return warn('Účet technika není dostupný.');
 const city=document.getElementById('pay-city')?.value,tier=document.getElementById('pay-tier')?.value,cat=document.getElementById('pay-cat')?.value,days=Number(document.getElementById('pay-days')?.value);
 if(tier==='Základní'){if(!t.cities.includes(city))return warn('Město není ve vašem profilu.');if(isBlock(t,city))return warn('Účet nebo město je blokováno.');const old=t.plans?.[city];if(old?.tier==='Základní')return warn('Základní už máte aktivní.');if(old&&['Standard','Premium'].includes(old.tier)&&old.expiry>Date.now()&&!confirm('Aktivní placený tarif bude nahrazen bezplatným Základní; v demu se zbývající doba nevrací. Pokračovat?'))return;t.plans=t.plans||{};t.plans[city]={tier:'Základní',expiry:253402300799000};audit(db,'Bezplatný tarif Základní vybrán',t.id,city);saved(db,{type:'free_plan_selected',techId:t.id,city});warn('Základní aktivován zdarma — bez QR platby.');return}
 if(!c.account||!c.qr)return warn('Platební účet nebo QR není nastaven.');
 const payerEntry=validateIdentity(t,'pay-identity');if(!payerEntry)return;
 if(!t.cities.includes(city)||!['Standard','Premium'].includes(tier)||!PERIODS.includes(days)||!t.appliances.includes(cat))return warn('Vyberte platné město, tarif, službu a dobu.');
 const amount=Number(officialPrice(db,city,tier,cat,days));if(!Number.isFinite(amount)||amount<=0)return warn('Chybná cena.');
 const p={id:generateId(db),variableSymbol:vs(db),type:'plan',techId:t.id,...masterInfo(t),payerEntry,city,tier,cat,days,amount,account:c.account,bank:c.bank,iban:c.iban,owner:c.owner,qr:c.qr,created:Date.now(),status:'Čeká na úhradu',appliedAt:null};p.paymentMessage='TS '+p.masterId+' / '+p.id;db.qrPayments.push(p);audit(db,'Vystaven QR převod — členství',t.id,p.id);saved(db,{type:'qr_payment_created',techId:t.id});warn('Platební pokyny připraveny, zatím bez aktivace.');}
function createBoost(){if(isAdmin())return;const db=init(load()),t=own(db),c=cfg();if(!t||!c.account||!c.qr)return warn('Platební účet nebo QR není nastaven.');
const payerEntry=validateIdentity(t,'pay-boost-identity');if(!payerEntry)return;
const city=document.getElementById('pay-boost-city')?.value,qty=Number(document.getElementById('pay-qty')?.value);if(!t.cities.includes(city)||!Number.isInteger(qty)||qty<1||qty>1000)return warn('Neplatné město nebo počet.');
const unit=Number(db.attemptPrices[city]??99);const amount=unit*qty;if(!(amount>0&&Number.isFinite(amount)))return warn('Chybná cena.');
const p={id:generateId(db),variableSymbol:vs(db),type:'boost',techId:t.id,...masterInfo(t),payerEntry,city,qty,unit,amount,account:c.account,bank:c.bank,iban:c.iban,owner:c.owner,qr:c.qr,created:Date.now(),status:'Čeká na úhradu',appliedAt:null};p.paymentMessage='TS '+p.masterId+' / '+p.id;db.qrPayments.push(p);audit(db,'Vystaven QR převod — pokusy',t.id,p.id);saved(db,{type:'qr_payment_created',techId:t.id});warn('Platební pokyny připraveny, zatím bez připsání pokusů.');}
function renderAdmin(db){init(db);const c=cfg(),workers=db.technicians||[],all=db.qrPayments.slice().reverse(),pending=all.filter(p=>p.status==='Čeká na úhradu'||p.status==='Ověřeno · blokováno');
return `<div class="panel"><h2>💳 Bankovní QR platby a ruční správa</h2><p class="sub">Změny účtu a QR se projeví v obou směrech projektu na stejném webu. Platba QR převodem není automaticky ověřena.</p>
<div class="notice warning"><strong>DEMO:</strong> nastavení a data jsou v prohlížeči bez zabezpečených administrátorských práv. Před zveřejněním musí být všechna nastavení chráněna serverovým přihlášením. Bankovní účet nesmí mít právo měnit technik.</div>
<div class="twocol"><div class="item"><h3>Nastavení příjemce platby</h3>
<label class="field">Příjemce / firma<input id="bank-owner" value="${esc(c.owner)}" placeholder="Obchodní firma nebo jméno"></label>
<label class="field">Banka<input id="bank-name" value="${esc(c.bank)}" placeholder="Název banky"></label>
<label class="field">Číslo účtu / kód banky<input id="bank-account" value="${esc(c.account)}" placeholder="123456789/0100"></label>
<label class="field">IBAN (volitelné)<input id="bank-iban" value="${esc(c.iban)}" placeholder="CZ…"></label>
<label class="field">Informace pro plátce<textarea id="bank-note" rows="2" placeholder="Pokyny k převodu">${esc(c.note)}</textarea></label>
<label class="field">Nahrát nový QR kód od banky (PNG/JPG/WebP)<input id="bank-qr-file" type="file" accept="image/png,image/jpeg,image/webp"></label>
<div class="actions"><button class="btn" onclick="TSPay.saveBank()">Uložit účet a QR</button><button class="btn ghost" onclick="TSPay.clearQR()">Odebrat QR obrázek</button></div>
<p class="notice warning">⚠ Pokud změníte číslo účtu nebo IBAN, musíte znovu nahrát QR od banky. Starý QR se automaticky odstraní. Zkontrolujte v bankovní aplikaci, že skenovaný QR skutečně uvádí nastavený účet. Vystavené žádosti mají původní údaje.</p></div>
<div class="item"><h3>Náhled QR platby</h3>${c.qr?`<div class="qr-wrap"><img class="qr-img" src="${c.qr}" alt="Aktuálně uložený bankovní QR kód"></div>`:'<div class="empty">Zatím není nahrán žádný QR kód.</div>'}<p><strong>${esc(c.account||'Účet není nastaven')}</strong></p><p>${esc(c.owner||'Příjemce není nastaven')}</p><p class="muted">QR obrázek může obsahovat pevné údaje. Částku a variabilní symbol musí plátce doplnit, pokud je QR neobsahuje.</p></div></div>
<div class="notice"><strong>🔔 Nové žádosti o nákup: ${unreadCount(db)}</strong> · upozornění této демонстрации видны только на текущем устройстве. <button class="btn ghost" onclick="TSPay.markRead()">Označit jako přečtené</button><p class="muted">Zobrazení žádosti neznamená přijetí platby. Ověření příchozí částky a variabilního symbolu je samostatný krok.</p></div>
<h3>QR platby čekající na ověření <span class="tag gold">${pending.length}</span></h3>
${pending.length?pending.map(p=>adminCard(db,p)).join(''):'<div class="empty">Žádné platby čekající na ověření.</div>'}
${adminNoticeList(db)}
<details><summary>Historie QR plateb (${all.length})</summary>${all.map(p=>adminCard(db,p)).join('')||'<div class="empty">Zatím prázdné.</div>'}</details>
<div class="hr"></div><h3>Ruční správa techniků a topenářů</h3><p class="muted">Vlastní stav pro tento obor. Zablokování má přednost i před uhrazeným tarifem. Veškeré ruční akce se zapisují do historie.</p>
<label class="field">Pracovník<select id="pay-manual-worker" onchange="TSPay.syncManualCities()">${workers.map(t=>`<option value="${esc(t.id)}">${esc(t.name)}</option>`).join('')}</select></label>
<label class="field">Město<select id="pay-manual-city">${options(workers[0]?.cities||[])}</select></label>
<div class="grid"><label class="field">Tarif<select id="pay-manual-tier"><option>Standard</option><option>Premium</option></select></label><label class="field">Počet dní<input id="pay-manual-days" type="number" min="1" max="3650" value="30"></label></div>
<div class="actions"><button class="btn" onclick="TSPay.manualPlan()">Nastavit / prodloužit</button><button class="btn warn" onclick="TSPay.toggleBlock('city')">Blokovat / odblokovat město</button><button class="btn warn" onclick="TSPay.toggleBlock('account')">Blokovat / odblokovat účet</button></div>
<div class="grid"><label class="field">Přidat počet pokusů (kladné celé číslo)<input type="number" min="1" id="pay-manual-qty" value="10"></label><label class="field">Důvod změny<input id="pay-manual-note" placeholder="Např. ruční platba / korekce" value=""></label></div>
<button class="btn alt" onclick="TSPay.manualAttempts()">Připsat pokusy ručně</button>
<h3>Historie zásahů</h3>${db.qrAudit.length?`<div class="audit-scroll">${db.qrAudit.slice(0,50).map(x=>`<div class="audit-entry"><strong>${esc(x.action)}</strong> · ${esc(x.techId||'—')} · ${new Date(x.at).toLocaleString('cs-CZ')}<br><span class="muted">${esc(x.details||'')}</span></div>`).join('')}</div>`:'<div class="empty">Zatím bez ručních změn.</div>'}
</div>`}
function adminCard(db,p){const t=getTech(db,p.techId);return `<div class="item"><div class="itemhead"><div><strong>${esc(t?.name||p.techId)} — ${p.type==='plan'?`${esc(p.tier)} ${esc(p.city)}, ${p.days} dní`:`${p.qty} pokusů, ${esc(p.city)}`}</strong><p class="muted">${esc(p.id)} · ${esc(p.variableSymbol)} · ${new Date(p.created).toLocaleString('cs-CZ')}</p></div><span class="tag ${p.appliedAt?'ok':'gold'}">${esc(p.status)}</span></div><p>Jméno a příjmení: <strong>${esc(p.masterName||t?.name||'—')}</strong> · ID technika: <strong>${esc(p.masterId||p.techId)}</strong></p><p>Údaj zadaný technikem: <strong>${esc(p.payerEntry||'starší žádost')}</strong> · zpráva k platbě: <strong>${esc(p.paymentMessage||'TS '+(p.masterId||p.techId)+' / '+p.id)}</strong></p><p><strong>${fmt(p.amount)}</strong> · účet ${esc(p.account)} · ${esc(p.bank||'')}</p>${p.status==='Čeká na úhradu'&&(p.account!==cfg().account||p.qr!==cfg().qr)?'<p class="notice warning">Staré platební údaje! Požádejte o novou žádost, původní nepotvrzujte bez ověření bankovního výpisu.</p>':''}${p.status==='Čeká na úhradu'?`<div class="actions"><button class="btn" onclick="TSPay.confirmBank('${esc(p.id)}')">Platba připsána v bance</button><button class="btn ghost" onclick="TSPay.reject('${esc(p.id)}')">Zamítnout / zrušit</button></div>`:p.status==='Ověřeno · blokováno'?`<p class="notice warning">Platba ověřena, ale účet či město zablokováno. Žádná automatická aktivace.</p><button class="btn alt" onclick="TSPay.release('${esc(p.id)}')">Po odblokování aktivovat</button>`:''}</div>`}
function refresh(){if(typeof render==='function')render()}
function saveBank(){if(!isAdmin())return warn('Přístup odepřen.');const c=cfg();const val=id=>document.getElementById(id)?.value.trim()||'';
const newer={...c,owner:val('bank-owner'),bank:val('bank-name'),account:val('bank-account'),iban:val('bank-iban'),note:val('bank-note')};
if(newer.account&&(!/^[0-9\- ]{1,25}\/\d{4}$/.test(newer.account)&&!/^[A-Z]{2}\d{2}[A-Z0-9 ]{10,34}$/.test(newer.account.toUpperCase())))return warn('Zadejte účet ve tvaru číslo/kód banky nebo platný formát IBAN.');
const f=document.getElementById('bank-qr-file')?.files?.[0];
const bankChanged=!!(c.account && (c.account!==newer.account || (c.iban||'').replace(/\s/g,'').toUpperCase()!==(newer.iban||'').replace(/\s/g,'').toUpperCase()));
if(bankChanged&&!f){newer.qr='';}

function store(){try{localStorage.setItem(CFG,JSON.stringify(newer));try{window.BroadcastChannel&&new BroadcastChannel('ts-bank-config').postMessage({type:'bank-config-updated'})}catch{}warn(bankChanged&&!f?'Bankovní účet se změnil. Starý QR byl z bezpečnostních důvodů odebrán. Nahrajte nový QR odpovídající účtu.':'Účet a QR uloženy pro tuto ukázku v prohlížeči.');refresh()}catch(err){warn('Nelze uložit obrázek, zvolte menší QR (max. 400 KB).')}}
if(f){if(!['image/png','image/jpeg','image/webp'].includes(f.type)||f.size>400000)return warn('QR musí být obrázek PNG/JPG/WebP do 400 KB.');const r=new FileReader();r.onload=()=>{newer.qr=String(r.result);store()};r.onerror=()=>warn('QR obrázek se nepodařilo načíst.');r.readAsDataURL(f);}else store()}
function clearQR(){if(!isAdmin()||!confirm('Odebrat uložený QR obrázek? Starší žádosti zůstávají beze změny.'))return;let c=cfg();c.qr='';localStorage.setItem(CFG,JSON.stringify(c));try{window.BroadcastChannel&&new BroadcastChannel('ts-bank-config').postMessage({type:'bank-config-updated'})}catch{}refresh()}
function requireAdminDb(){if(!isAdmin())throw Error('Pouze administrátor');return init(load())}
function activate(db,p,t){if(p.appliedAt)return false;if(isBlock(t,p.city))return false;if(p.type==='plan'){
if(!t.cities.includes(p.city)||!['Standard','Premium'].includes(p.tier)||!PERIODS.includes(Number(p.days)))return false;
const prev=t.plans[p.city]?.expiry||0;t.plans[p.city]={tier:p.tier,expiry:Math.max(Date.now(),prev)+p.days*86400000};
}else{if(!t.cities.includes(p.city)||!Number.isInteger(p.qty)||p.qty<1)return false;t.attempts=(Number(t.attempts)||0)+p.qty}
p.appliedAt=Date.now();p.status='Aktivováno';audit(db,'Aktivace po ověření',t.id,p.id);return true}
function confirmBank(id){let db;try{db=requireAdminDb()}catch{return}const p=getPayment(db,id);if(!p||p.status!=='Čeká na úhradu')return warn('Platba již byla zpracována.');if(!confirm('Potvrzujete, že peníze skutečně PŘIŠLY na účet podle bankovního výpisu? Nejde jen o screenshot.'))return;
const t=getTech(db,p.techId);if(!t)return warn('Pracovník neexistuje.');p.bankVerifiedAt=Date.now();if(!activate(db,p,t)) {p.status='Ověřeno · blokováno';audit(db,'Platba ověřena; aktivace zadržena',t.id,p.id)}saved(db,{type:'qr_payment_verified',techId:p.techId});}
function release(id){const db=requireAdminDb(),p=getPayment(db,id);if(!p||p.status!=='Ověřeno · blokováno'||!p.bankVerifiedAt)return warn('Neplatná žádost.');const t=getTech(db,p.techId);if(!t)return;if(!activate(db,p,t))return warn('Odblokujte pracovníka i město a ověřte, že město je v profilu.');saved(db,{type:'qr_payment_activated',techId:t.id})}
function reject(id){const db=requireAdminDb(),p=getPayment(db,id);if(!p||p.status!=='Čeká na úhradu')return;if(!confirm('Zrušit čekající žádost bez aktivace?'))return;p.status='Zamítnuto / zrušeno';audit(db,'Zrušena čekající platba',p.techId,p.id);saved(db,{type:'qr_payment_rejected'})}
function selected(){const db=requireAdminDb(),id=document.getElementById('pay-manual-worker')?.value,city=document.getElementById('pay-manual-city')?.value,t=getTech(db,id);if(!t||!t.cities.includes(city))throw Error('Vyberte pracovníka a jeho město.');return {db,t,city,note:document.getElementById('pay-manual-note')?.value.trim()||'Neuvedeno'}}
function syncManualCities(){const db=load(),id=document.getElementById('pay-manual-worker')?.value,t=getTech(db,id),sel=document.getElementById('pay-manual-city');if(sel)sel.innerHTML=options(t?.cities||[])}
function manualPlan(){let x;try{x=selected()}catch(err){return warn(err.message)}const {db,t,city,note}=x;const days=Number(document.getElementById('pay-manual-days')?.value),tier=document.getElementById('pay-manual-tier')?.value;
if(!Number.isInteger(days)||days<1||days>3650||!['Standard','Premium'].includes(tier))return warn('Neplatný tarif nebo počet dní.');if(isBlock(t,city))return warn('Nejprve odblokujte účet a město.');
const old=t.plans[city]?.expiry||0;t.plans[city]={tier,expiry:Math.max(Date.now(),old)+days*86400000};audit(db,'Ruční nastavení/prodloužení '+tier,t.id,city+' · '+days+' dní · '+note);saved(db,{type:'manual_plan',techId:t.id,city})}
function manualAttempts(){let x;try{x=selected()}catch(err){return warn(err.message)}const {db,t,city,note}=x,qty=Number(document.getElementById('pay-manual-qty')?.value);if(!Number.isInteger(qty)||qty<1||qty>100000)return warn('Zadejte kladný celý počet.');if(isBlock(t,city))return warn('Pracovník nebo město je blokováno.');t.attempts=(Number(t.attempts)||0)+qty;audit(db,'Ruční přidělení pokusů',t.id,city+' · +'+qty+' · '+note);saved(db,{type:'manual_attempts',techId:t.id})}
function toggleBlock(scope){let x;try{x=selected()}catch(err){return warn(err.message)}const {db,t,city,note}=x;if(scope==='account'){t.blocked=!t.blocked;audit(db,t.blocked?'Blokace účtu':'Odblokování účtu',t.id,note)}else{t.blockedCities||=[];if(t.blockedCities.includes(city)){t.blockedCities=t.blockedCities.filter(c=>c!==city);audit(db,'Odblokování města',t.id,city+' · '+note)}else{t.blockedCities.push(city);audit(db,'Blokace města',t.id,city+' · '+note)}}saved(db,{type:'account_block_changed',techId:t.id,city})}
function copy(value){if(navigator.clipboard?.writeText)navigator.clipboard.writeText(value).then(()=>warn('Zkopírováno.')).catch(()=>prompt('Zkopírujte:',value));else prompt('Zkopírujte:',value)}
window.addEventListener('storage',ev=>{if(ev.key===CFG){const pageVisible=document.querySelector('#pay-city, #bank-owner');if(pageVisible && typeof render==='function')render()}});
try{if(window.BroadcastChannel){const qrBroadcast=new BroadcastChannel('ts-bank-config');qrBroadcast.onmessage=()=>{if(document.querySelector('#pay-city, #bank-owner')&&typeof render==='function')render()}}}catch{}
window.TSPay={unreadCount,markRead,renderAdmin,renderWorker,updatePlanChoice,saveBank,clearQR,createPlan,createBoost,confirmBank,release,reject,manualPlan,manualAttempts,toggleBlock,syncManualCities,copy};
})();