-- Technik Soused · шаг 155
-- Дополняет уже выполненный SQL одобрения (шаг 154).
-- Функция возвращает профили ТОЛЬКО главному администратору.
BEGIN;

CREATE OR REPLACE FUNCTION public.ts_admin_list_technicians()
RETURNS TABLE (
  user_id uuid,
  full_name text,
  category text,
  region text,
  city text,
  services text[],
  tier text,
  review_status text,
  approved_at timestamptz,
  created_at timestamptz
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  IF (SELECT auth.uid()) IS NULL OR NOT EXISTS (
    SELECT 1 FROM public.ts_user_roles r
    WHERE r.user_id = (SELECT auth.uid())
      AND r.role = 'owner'
  ) THEN
    RAISE EXCEPTION 'Access denied' USING ERRCODE = '42501';
  END IF;

  RETURN QUERY
  SELECT
    t.user_id, t.full_name, t.category, t.region, t.city,
    t.services, t.tier, t.review_status, t.approved_at,
    t.created_at
  FROM public.ts_technicians t
  ORDER BY
    CASE t.review_status
      WHEN 'pending' THEN 0
      WHEN 'approved' THEN 1
      ELSE 2
    END,
    t.created_at DESC
  LIMIT 500;
END;
$$;

REVOKE ALL ON FUNCTION public.ts_admin_list_technicians()
  FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.ts_admin_list_technicians()
  TO authenticated;
COMMIT;
