/* Technik Soused — offline DEMO auto-routing rules. Production rules must be server enforced. */
(function(root){ 'use strict';
const KEY='ts_auto_base_rules_v1',HOLD=15*60*1000;
const REGIONS={"Hlavní město Praha":["Praha"],"Středočeský kraj":["Kladno","Beroun","Benešov","Příbram","Mladá Boleslav","Kolín","Kutná Hora","Nymburk","Rakovník","Mělník","Slaný","Čáslav","Poděbrady","Brandýs nad Labem-Stará Boleslav"],"Jihočeský kraj":["České Budějovice","Tábor","Písek","Strakonice","Jindřichův Hradec","Český Krumlov","Prachatice"],"Plzeňský kraj":["Plzeň","Klatovy","Domažlice","Rokycany","Tachov","Sušice"],"Karlovarský kraj":["Karlovy Vary","Cheb","Sokolov","Mariánské Lázně","Ostrov"],"Ústecký kraj":["Ústí nad Labem","Teplice","Děčín","Litoměřice","Most","Chomutov","Louny","Žatec"],"Liberecký kraj":["Liberec","Jablonec nad Nisou","Česká Lípa","Semily","Turnov"],"Královéhradecký kraj":["Hradec Králové","Trutnov","Náchod","Jičín","Rychnov nad Kněžnou","Dvůr Králové nad Labem"],"Pardubický kraj":["Pardubice","Chrudim","Svitavy","Ústí nad Orlicí","Česká Třebová"],"Kraj Vysočina":["Jihlava","Třebíč","Havlíčkův Brod","Pelhřimov","Žďár nad Sázavou"],"Jihomoravský kraj":["Brno","Blansko","Břeclav","Hodonín","Vyškov","Znojmo","Boskovice"],"Olomoucký kraj":["Olomouc","Přerov","Prostějov","Šumperk","Jeseník"],"Zlínský kraj":["Zlín","Kroměříž","Uherské Hradiště","Vsetín","Valašské Meziříčí"],"Moravskoslezský kraj":["Ostrava","Opava","Karviná","Frýdek-Místek","Nový Jičín","Havířov","Třinec"]};
const CATS=[{id:'appliance',cs:'Domácí spotřebiče',ru:'Бытовая техника'},{id:'plumber',cs:'Instalatéři',ru:'Сантехники'},{id:'heating',cs:'Topení',ru:'Отопление'},{id:'electric',cs:'Elektrikáři',ru:'Электрики'},{id:'wood',cs:'Truhláři',ru:'Столяры'},{id:'paint',cs:'Malíři',ru:'Маляры'}];
const EQUIPMENT={"appliance":["Jiné","Ostatní","Pračka","Myčka nádobí","Lednice / mrazák","Sušička","Sporák / trouba","Kávovary","Jiný spotřebič","Plynové kotle","Plynové sporáky","Plynové varné desky","Plynové ohřívače vody","Elektrické kotle","Elektrické bojlery / ohřívače vody"],"heating":["Opravy topení", "Topení a radiátory", "Montáž radiátorů", "Výměna radiátorů", "Rozvody topení", "Podlahové vytápění", "Plynové kotle", "Elektrické kotle", "Kondenzační kotle", "Servis kotlů", "Bojlery a ohřívače vody", "Oběhová čerpadla", "Termostaty a regulace", "Odvzdušnění topení", "Havárie topení", "Jiné"],"plumber":["Havárie vody","Výměna baterie","Oprava vodovodu","Čištění odpadu","Ucpaný odpad","WC a splachování","Sprcha a vana","Ohřívač vody","Výměna sifonu","Montáž umyvadla","Instalace rozvodů","Jiné"],"electric":["Elektroinstalace bytů a domů","Opravy elektrických rozvodů","Výměna zásuvek a vypínačů","Montáž světel a svítidel","Rozvaděče a jističe","Revize elektroinstalace","Hledání elektrické závady","Montáž proudových chráničů","Připojení elektrických spotřebičů","Výměna elektrických kabelů","Elektroinstalace v kuchyni a koupelně","Oprava domovního zvonku","Venkovní osvětlení","Elektroinstalace garáží","Chytrá domácnost","Nabíjení elektromobilu – elektroinstalace","Havarijní elektrikář","Jiné"],"wood":["Výroba nábytku na míru","Montáž kuchyňské linky","Opravy nábytku","Montáž skříní a polic","Vestavěné skříně","Dřevěné dveře a zárubně","Pokládka dřevěných podlah","Renovace dřevěných povrchů","Schody a zábradlí ze dřeva","Pergoly a terasy","Montáž nábytku","Truhlářské úpravy a opravy","Tesařské konstrukce a krovy","Dřevěné přístřešky a altány","Opravy krovů","Jiné"],"paint":["Malování pokojů","Výmalba bytu","Výmalba domu","Malování kanceláří","Penetrace stěn","Opravy omítek a prasklin","Štukování","Tapetování","Odstranění starých tapet","Nátěry dveří a zárubní","Nátěry radiátorů","Dekorativní malby a stěrky","Fasádní nátěry","Malování po rekonstrukci","Tmelení a broušení stěn","Nátěry dřevěných povrchů","Jiné"]};
const fold=x=>String(x||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim().replace(/\s+/g,' ').toLocaleLowerCase('cs');
function regionFor(city){const name=fold(city);if(!name)return '';if(name==='praha')return 'Hlavní město Praha';const found=Object.entries(REGIONS).filter(([,cities])=>cities.some(c=>fold(c)===name));return found.length===1?found[0][0]:'';}
function canonRegion(r){const n=fold(r);if(n==='praha'||n==='hlavni mesto praha')return 'Hlavní město Praha';return Object.keys(REGIONS).find(x=>fold(x)===n)||'';}
function load(){try{const x=JSON.parse(localStorage.getItem(KEY)||'[]');return Array.isArray(x)?x.filter(r=>r&&typeof r==='object'):[]}catch{return []}}
function save(rules){if(!Array.isArray(rules))return false;localStorage.setItem(KEY,JSON.stringify(rules));root.dispatchEvent(new Event('ts-auto-base-change'));return true;}
function equipmentFor(cat,value){
 const raw=String(value==null?'*':value).trim();
 if(!raw||raw==='*')return '*';
 const found=(EQUIPMENT[cat]||[]).find(x=>fold(x)===fold(raw));
 if(!found)throw new Error('Выбери оборудование или вид работ из списка');
 return found;
}
function addRule({category,scope,region,city,equipment='*'}){
 if(!CATS.some(c=>c.id===category))throw new Error('Неизвестная категория');
 if(!['region','city'].includes(scope))throw new Error('Выбери регион или город');
 region=canonRegion(region);if(!region)throw new Error('Выбери область / kraj');
 city=String(city||'').trim();if(scope==='city'&&!city)throw new Error('Выбери или впиши город');
 if(city.length>90)throw new Error('Слишком длинное название города');
 equipment=equipmentFor(category,equipment);
 const rules=load();
 if(rules.some(r=>r.category===category&&r.scope===scope&&fold(r.region)===fold(region)&&fold(r.city||'')===fold(scope==='city'?city:'')&&fold(r.equipment||'*')===fold(equipment)&&r.enabled!==false))throw new Error('Такое активное правило уже есть');
 const rule={id:'ab-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,8),category,scope,region,city:scope==='city'?city:'',equipment,brands:'*',workTypes:'*',enabled:true,createdAt:Date.now()};
 rules.push(rule);save(rules);return rule;
}
function removeRule(id){const before=load(),after=before.filter(r=>r.id!==id);if(after.length!==before.length)save(after);return before.length!==after.length;}
function enableRule(id,enabled){const all=load(),r=all.find(x=>x.id===id);if(!r)return false;r.enabled=!!enabled;if(enabled)r.createdAt=Date.now();save(all);return true;}
function matching(order,category){
 if(!order||!CATS.some(c=>c.id===category))return null;
 const city=fold(order.city),actualR=canonRegion(order.region)||regionFor(order.city);
 // In this form, the appliance/service field describes the requested equipment or type of work.
 const device=fold(order.appliance||order.service||order.device||'');
 const eligible=load().filter(r=>{
  if(r.enabled===false||r.category!==category||canonRegion(r.region)!==actualR)return false;
  if(r.scope==='city'&&fold(r.city)!==city)return false;
  // Legacy rules without equipment are understood as 'all equipment / all work types'.
  if(r.equipment&&r.equipment!=='*'&&fold(r.equipment)!==device)return false;
  return true; // No filtering on brand and issue: all brands, models and work descriptions.
 });
 // Prefer the most specific match, independently of the order rules were created.
 eligible.sort((a,b)=>((b.scope==='city'?2:0)+(b.equipment&&b.equipment!=='*'?1:0))-((a.scope==='city'?2:0)+(a.equipment&&a.equipment!=='*'?1:0)));
 return eligible[0]||null;
}
function apply(order,category,when){
 if(!order||order.status!=='Nová'||order.assigned||order.tsInBase||order.tsInitialExpired||order.tsServiceAt)return false;
 if(!CATS.some(c=>c.id===category))return false;
 const created=Number(order.created)||Number(when)||Date.now();
 // Every NEW order enters Base immediately. Manual region/equipment rules are optional classification metadata.
 const r=matching(order,category);
 order.status='V databázi';order.tsInBase=true;order.tsBaseAddedAt=created;
 order.tsBaseUntil=created+HOLD;order.tsAdminUntil=created+HOLD;
 order.tsAutoBase=true;order.tsBaseDefault=true;
 if(r){order.tsAutoBaseRuleId=r.id;order.tsAutoBaseRuleLabel=category+' / '+r.region+(r.scope==='city'?' / '+r.city:'')+' / '+(r.equipment||'*');}
 order.assigned='';return true;
}
function reconcile(db,category){
 // Do NOT move old orders into Base just because an administrator later opens a page.
 // Preserve the previous targeted migration behavior for explicitly configured rules only.
 let changed=0;for(const o of db?.orders||[]){
  const r=matching(o,category);
  if(r&&Number(o.created||0)>=Number(r.createdAt||0)&&apply(o,category))changed++;
 }return changed;
}
root.TSAutoBase={KEY,HOLD,REGIONS,CATS,EQUIPMENT,fold,regionFor,canonRegion,load,save,addRule,removeRule,enableRule,matching,apply,reconcile};
})(window);
