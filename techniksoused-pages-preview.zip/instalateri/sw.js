const CACHE='ts-instalateri-public-v2';
const ASSETS=['./index.html','./registrace.html','./podminky.html','./ui.css','./portal.js'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting()).catch(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil((async()=>{for(const k of await caches.keys()){if(k.startsWith('ts-instalateri-')&&k!==CACHE)await caches.delete(k)}await self.clients.claim()})()));
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method!=='GET'||u.origin!==self.location.origin)return;
// Always fetch private cabinet/admin/auth content from network; avoid caching API and query tokens.
if(/(?:kabinet|admin|obnoveni-hesla)\.html$/.test(u.pathname)||u.pathname.includes('/api/')||u.search)return;
if(!ASSETS.some(a=>u.pathname.endsWith('/'+a.replace('./',''))))return;
e.respondWith(fetch(e.request).then(r=>{if(r.ok){const c=r.clone();caches.open(CACHE).then(cache=>cache.put(e.request,c)).catch(()=>{})}return r}).catch(()=>caches.match(e.request)))});
