/* Technik Soused — závislé značky podle typu spotřebiče, veřejný seznam + ruční zadání. */
(function(){
'use strict';
const DATA={"washer":["AEG","Amica","Ariston","Arçelik","Asko","Bauknecht","Beko","Blomberg","Bomann","Bompani","Bosch","Brandt","Candy","Candy Hoover","Candy Smart","Cecotec","Concept","Daewoo","Electra","Electrolux","ETA","Fagor","Finlux","Fisher & Paykel","Frigidaire","Fust","GE Appliances","Gorenje","Grundig","Haier","Hisense","Hoover","Hotpoint","Hotpoint-Ariston","Hyundai","IKEA","Indesit","Kenmore","Klarstein","LG","LORD","Maytag","Midea","Miele","Mora","Neff","Panasonic","Philco","Privileg","Romo","Roper","Samsung","Sangiorgio","Schaub Lorenz","Sharp","Siemens","Smeg","Snaigė","Speed Queen","TCL","TEKA","Vestel","Whirlpool","Zanussi","Zerowatt"],"dishwasher":["AEG","Amica","Asko","Bauknecht","Beko","Blomberg","Bomann","Bompani","Bosch","Brandt","Candy","Candy Hoover","Cecotec","Concept","Electrolux","ETA","Fagor","Fisher & Paykel","Frigidaire","Gaggenau","GE Appliances","Gorenje","Grundig","Haier","Hisense","Hoover","Hotpoint","Hotpoint-Ariston","IKEA","Indesit","Kenmore","KitchenAid","Klarstein","LG","LORD","Maytag","Midea","Miele","Mora","Neff","Philco","Samsung","Schaub Lorenz","Sharp","Siemens","Smeg","TEKA","Whirlpool","Zanussi"],"fridge":["AEG","Amica","Arçelik","Bauknecht","Beko","Beko HarvestFresh","Blomberg","Bomann","Bosch","Brandt","Candy","Candy Hoover","Cecotec","Concept","Daewoo","Electrolux","ETA","Fagor","Fisher & Paykel","Frigidaire","Gaggenau","GE Appliances","Gorenje","Grundig","Haier","Hisense","Hitachi","Hoover","Hotpoint","Hotpoint-Ariston","Hyundai","IKEA","Indesit","Kenmore","Klarstein","LG","Liebherr","LORD","Midea","Miele","Mitsubishi Electric","Mora","Neff","Panasonic","Philco","Samsung","Samsung Bespoke","Severin","Sharp","Siemens","Smeg","Snaigė","Sub-Zero","TEKA","Toshiba","Vestfrost","Whirlpool","Zanussi"],"dryer":["AEG","Amica","Asko","Bauknecht","Beko","Blomberg","Bomann","Bosch","Candy","Candy Hoover","Cecotec","Concept","Electrolux","ETA","Fagor","Frigidaire","GE Appliances","Gorenje","Grundig","Haier","Hisense","Hoover","Hotpoint","Hotpoint-Ariston","Indesit","Kenmore","LG","LORD","Maytag","Midea","Miele","Philco","Samsung","Sharp","Siemens","Smeg","Speed Queen","Whirlpool","Zanussi"],"oven":["AEG","AGA","Amica","Ariston","Bartscher","Bauknecht","Beko","Belling","Bertazzoni","Blomberg","Bomann","Bosch","Brandt","Candy","Candy Hoover","Cecotec","Concept","De Dietrich","Electrolux","Electrolux Professional","ETA","Fagor","Falcon","Fimar","Gaggenau","Gastro M","Gastroback","Giorik","Gorenje","Gorenje+","Grundig","Haier","Hisense","Hotpoint","Hotpoint-Ariston","IKEA","Indesit","KitchenAid","Klarstein","La Germania","Lainox","Lofra","LORD","Mareno","Midea","Miele","Mora","Neff","Orava","Philco","Rational","Samsung","Siemens","Smeg","TEKA","Whirlpool","Zanussi"],"coffee":["AEG","Ankarsrum","Ariete","Ascaso","Astoria","Baratza","Bartscher","Beko","Bezzera","Bialetti","Bosch","BOSCH Tassimo","Braun","Bravilor Bonamat","Breville","Bunn","Caffitaly","Cafina","Caso","Catler","Cecotec","Concept","Conti","Cuisinart","Dalla Corte","Dalla Corte Mina","DeLonghi","Delonghi Dinamica","De’Longhi","De’Longhi Magnifica","Dometic","Dr. Coffee","ECM","Electrolux","ETA","Eversys","Faema","Fiamma","Fiorenzato","FrancisFrancis","Franke","Gaggia","Gaggia Milano","Gastroback","Gorenje","Graef","Grimac","Handpresso","Hendi","Hyundai","Illy","Jura","JURA Professional","Kalerm","KitchenAid","Klarstein","Krups","L-Or Barista","La Cimbali","La Marzocco","La Pavoni","La San Marco","La Spaziale","LaRhea","Lavazza","Lelit","Lelit Bianca","LOR","Mahlkönig","Melitta","Miele","Moccamaster","Moulinex","Necta","Nescafé Dolce Gusto","Nespresso","Nivona","Nuova Simonelli","Orava","Oscar","Panasonic","Philips","Philips Saeco","Quick Mill","Rancilio","Rhea Vendors","Rocket Espresso","Russell Hobbs","Saeco","Saeco Incanto","Sage","Sanremo","Schaerer","Schaerer Coffee Art","Severin","Siemens","Smeg","Solis","Spidem","Spinn","Tassimo","Tchibo","TEKA","Thermoplan","Vibiemme","Victoria Arduino","Wittenborg","WMF","Zelmer","Zojirushi"],"gas_boiler":["ACV","Arca","Ariston","Atmos","Attack","Baxi","Beretta","Biasi","Bosch","Brötje","Buderus","Caldaia","Chaffoteaux","Daikin","Dakon","De Dietrich","Electrolux","Ferroli","Fondital","Fég","Geminox","Gorenje","Hermann","Hermann Saunier Duval","Hoval","Imergas","Immergas","Intergas","Junkers","Kiturami","Kospel","Lamborghini Caloreclima","M.H.I.","Mora","Novaservis","Oertli","Protherm","Rapido","Remeha","Riello","Robur","Saunier Duval","Sime","Thermona","Unical","Vaillant","Viadrus","Viessmann","Warmhaus","Wolf","Worcester Bosch"],"gas_stove":["AEG","AGA","Amica","Ariston","Bartscher","Baumatic","Beko","Belling","Bertazzoni","Bompani","Bosch","Candy","Electrolux","Fagor","Falcon","Fimar","Gaggenau","Gastro M","Giorik","Gorenje","Hotpoint","Hotpoint-Ariston","IKEA","Indesit","Klarstein","La Germania","Lofra","Mareno","Mora","Neff","Siemens","Smeg","TEKA","Whirlpool","Zanussi"],"gas_hob":["AEG","Amica","Ariston","Bauknecht","Beko","Bertazzoni","Bompani","Bosch","Candy","Electrolux","Fagor","Foster","Franke","Gaggenau","Gorenje","Hotpoint","IKEA","Indesit","Klarstein","Kuppersbusch","La Germania","Lofra","Miele","Mora","Neff","Siemens","Smeg","TEKA","Whirlpool","Zanussi"],"gas_water":["AO Smith","Ariston","Atlantic","Baxi","Beretta","Bosch","Buderus","Cointra","Dakon","Dražice","Fagor","Ferroli","Gorenje","Hajdu","Immergas","Junkers","Mora","Protherm","Rheem","Rinnai","Saunier Duval","Thermex","Thermona","Vaillant","Viessmann","Zanussi"],"electric_boiler":["ACV","Ariston","Attack","Baxi","Bosch","Buderus","Dakon","De Dietrich","Dražice","Electrolux","Elíz","Ferroli","Geminox","Gorenje","Hajdu","Heatrae Sadia","Kospel","Kospel EKCO","Kotlospol","Mora","Protherm","Raja","Ray","Stiebel Eltron","Thermex","Thermona","Vaillant","Viessmann","Wolf","Zodiac"],"electric_water":["A.O. Smith","ACV","AEG","Ariston","Ariston Velis","Atlantic","Baxi","Bosch","Clage","De Dietrich","Dražice","Dražice OKCE","Electrolux","Elíz","Fagor","Gorenje","Haier","Hajdu","Kospel","Kospel SW","Mora","NIBE","OKCE","Olympia","Protherm","Rheem","Rinnai","Sime","Stiebel Eltron","Tatramat","Tesy","Thermex","Vaillant","Viessmann","Whirlpool","Zanussi"],"generic":["A.O. Smith","ACV","AEG","AGA","Amana","Amica","Ankarsrum","AO Smith","Arca","Ardes","Ariete","Ariston","Ariston Velis","Arçelik","Ascaso","Asko","Astoria","Atlantic","Atmos","Attack","Baratza","Bartscher","Bauknecht","Baumatic","Baxi","Beko","Beko HarvestFresh","Belling","Beretta","Bertazzoni","Bezzera","Bialetti","Biasi","Blomberg","Bomann","Bompani","Bosch","BOSCH Tassimo","Brandt","Brasilia","Braun","Bravilor Bonamat","Breville","Brötje","Buderus","Bunn","Caffitaly","Cafina","Caldaia","Candy","Candy Hoover","Candy Smart","Carimali","Casadio","Caso","Catler","CDA","Cecotec","Chaffoteaux","Cimbali","Clage","Clatronic","Cointra","Concept","Conti","Cuisinart","Cylinda","Dacor","Daewoo","Daikin","Dak on","Dakon","Dalla Corte","Dalla Corte Mina","De Dietrich","Defy","DeLonghi","Delonghi Dinamica","De’Longhi","De’Longhi Magnifica","Dolce Gusto","Dometic","Dr. Coffee","Dražice","Dražice OKCE","Dualit","Dyson","ECG","ECM","Edesa","Egro","Elba","Electra","Electrolux","Electrolux Professional","Elektra","Elektra Bregenz","Elica","Elin","Elíz","Emerio","Espressione","ETA","Eumenia","Eversys","Expobar","Faber","Faema","Fagor","Falcon","Falmec","Fellow","Ferroli","Fiamma","Fimar","Finlux","Fiorenzato","Fisher & Paykel","Flair Espresso","Fondital","Fornelli","Foster","FrancisFrancis","Franke","Frigidaire","Fust","Fég","G3 Ferrari","Gaggenau","Gaggia","Gaggia Milano","Gastro M","Gastroback","GE Appliances","Gemini","Geminox","Giorik","Glen Dimplex","Gorenje","Gorenje+","Graef","Gram","Grimac","Grundig","Haden","Haier","Hajdu","Hamilton Beach","Handpresso","Hansa","Hario","Heatrae Sadia","Hendi","Hermann","Hermann Saunier Duval","HiBREW","Hisense","Hitachi","Hoover","Hotpoint","Hotpoint-Ariston","Hoval","Hyundai","Häfele","Iberital","Iberna","IKEA","Illy","Imergas","Immergas","Indesit","Intergas","Junkers","Jura","JURA Professional","Kalerm","Kenmore","Kenwood","KitchenAid","Kiturami","Klarstein","Kospel","Kospel EKCO","Kospel SW","Kotlospol","Krups","Kuppersbusch","L-Or Barista","La Cimbali","La Germania","La Marzocco","La Pavoni","La San Marco","La Spaziale","Lainox","Lamborghini Caloreclima","LaRhea","Lava","Lavazza","Lelit","Lelit Bianca","LG","Liebherr","Lofra","LOR","LORD","M.H.I.","Mabe","Mahlkönig","Manta","Mareno","Maytag","Melitta","Midea","Miele","Mitsubishi Electric","Moccamaster","Mora","Morris","Moulinex","Nardi","Necta","Nedis","Neff","Nescafé Dolce Gusto","Nespresso","New World","NIBE","Ninja","Nivona","Nordmende","Novamatic","Novaservis","Novis","Nuova Simonelli","Oertli","OKCE","Olympia","Orava","Oscar","Oster","Panasonic","Pando","Pelgrim","Philco","Philips","Philips Saeco","Pitsos","Polti","Princess","Privileg","ProfiCook","Profitec","Protherm","Pyramis","Quick Mill","Raja","Rancilio","Rancilio Silvia","Rangemaster","Rapido","Rational","Ravanson","Ray","Regulus","Remeha","Rex","Rhea Vendors","Rheem","Riello","Rinnai","Ritter","Robur","Rocket Espresso","Rohnson","Rommelsbacher","Romo","Roper","Rosenlew","Rowenta","Russell Hobbs","Saeco","Saeco Incanto","Sage","Samsung","Samsung Bespoke","Sangiorgio","Sanremo","Sanyo","Saunier Duval","Sauter","Schaerer","Schaerer Coffee Art","Schaub Lorenz","Sencor","Senseo","Severin","Sharp","Siemens","SilverCrest","Sime","Sinbo","Singer","Smeg","Snaigė","Solac","Solis","Speed Queen","Spidem","Spinn","Stiebel Eltron","Stoves","Sub-Zero","Swan","Tassimo","Tatramat","Taurus","Tchibo","TCL","Technivorm","Tefal","TEKA","Tesla","Tesy","Thermador","Thermex","Thermona","Thermoplan","Thomson","Toshiba","Tristar","Ufesa","Unical","Unold","UPO","V-ZUG","Vaillant","Vax","Vesta","Vestel","Vestfrost","Viadrus","Vibiemme","Victoria Arduino","Viessmann","Viking","Vivax","Waring","Warmhaus","Wega","Westinghouse","Whirlpool","White Knight","Wilfa","Witt","Wittenborg","WMF","Wolf","Worcester Bosch","Yale","Zanker","Zanussi","Zelmer","Zerowatt","Zilan","Zodiac","Zojirushi","Zoppas","ZUG","Zwilling"]};
const CATEGORY={
 'pračka':'washer','pracka':'washer','pračky':'washer',
 'myčka nádobí':'dishwasher','mycka nadobi':'dishwasher','myčky nádobí':'dishwasher',
 'lednice / mrazák':'fridge','lednice a mrazák':'fridge','lednice':'fridge','mrazák':'fridge',
 'sušička':'dryer','susicka':'dryer',
 'sporák / trouba':'oven','sporák a trouba':'oven','trouba / sporák':'oven',
 'kávovary':'coffee','kávovary / kávomaty':'coffee',
 'plynové kotle':'gas_boiler','plynové sporáky':'gas_stove','plynové varné desky':'gas_hob',
 'plynové ohřívače vody':'gas_water','elektrické kotle':'electric_boiler',
 'elektrické bojlery / ohřívače vody':'electric_water',
 'ostatní':'generic','jiné':'generic','jiný spotřebič':'generic'
};
const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('cs').trim();
const categoryFor=s=>CATEGORY[String(s||'').trim().toLocaleLowerCase('cs')]||CATEGORY[norm(s)]||'generic';
const listFor=type=>DATA[categoryFor(type)]||DATA.generic;
const known=(type,brand)=>listFor(type).some(b=>norm(b)===norm(brand));
window.TSBrandCatalog={listFor,known,isUnknown:(t,b)=>Boolean(b&&norm(b)!=='jine'&&norm(b)!=='ostatni'&&!known(t,b))};
function setup(typeId,brandId,listId){
 const type=document.getElementById(typeId),brand=document.getElementById(brandId),list=document.getElementById(listId);
 if(!type||!brand||!list)return;
 const help=document.getElementById(brandId+'Help');
 let previousValue='';
 // Two ways to choose: a reliable native select on phones, plus search / manual typing.
 const chooser=document.createElement('select');
 chooser.id=brandId+'Choose';
 chooser.className='ts-brand-chooser';
 chooser.setAttribute('aria-label','Vyberte výrobce pro zvolené zařízení');
 chooser.setAttribute('title','Vyberte značku spotřebiče');
 chooser.disabled=true;
 brand.parentNode.insertBefore(chooser,brand);
 brand.classList.add('ts-brand-manual');
 const manualLabel=document.createElement('span');
 manualLabel.className='ts-brand-manual-label';
 manualLabel.textContent='Nebo napište značku ručně:';
 brand.parentNode.insertBefore(manualLabel,brand);
 function update(preserve=false){
   const selected=type.value;
   const options=selected?listFor(selected):[];
   const currentValue=brand.value.trim();
   const frag=document.createDocumentFragment(), datalist=document.createDocumentFragment();
   const placeholder=document.createElement('option');placeholder.value='';placeholder.textContent=selected?'Vyberte značku…':'Nejprve vyberte zařízení';frag.append(placeholder);
   options.forEach(name=>{if(name==='Jiné'||name==='Ostatní')return;
     const o=document.createElement('option');o.value=name;o.textContent=name;frag.append(o);
     const hint=document.createElement('option');hint.value=name;datalist.append(hint);
   });
   const other=document.createElement('option');other.value='Jiné';other.textContent='Jiné – moje značka není v seznamu';frag.append(other);
   const otherHint=document.createElement('option');otherHint.value='Jiné';datalist.append(otherHint);
   chooser.replaceChildren(frag);list.replaceChildren(datalist);
   const hasSelected=Boolean(selected);
   chooser.disabled=!hasSelected;brand.disabled=!hasSelected;
   if(!preserve&&previousValue&&previousValue!==selected){brand.value='';}
   previousValue=selected;
   brand.placeholder=hasSelected?'Začněte psát např. Bosch, LG, Jura…':'Nejprve vyberte zařízení';
   if(help)help.textContent=hasSelected?'Nenašli jste značku? Napište ji níže nebo zvolte Jiné.':'Nejprve vyberte typ zařízení.';
   const exact=options.find(name=>norm(name)===norm(brand.value.trim()));
   chooser.value=exact||((brand.value.trim() && norm(brand.value.trim())==='jine')?'Jiné':'');
 }
 chooser.addEventListener('change',()=>{
   if(!chooser.value)return;
   if(chooser.value==='Jiné'){
     brand.value='Jiné';
     brand.focus();brand.select();
   }else{brand.value=chooser.value;}
   brand.dispatchEvent(new Event('input',{bubbles:true}));
   brand.dispatchEvent(new Event('change',{bubbles:true}));
 });
 brand.addEventListener('input',()=>{
   const v=brand.value.trim();const exact=listFor(type.value).find(name=>norm(name)===norm(v));
   chooser.value=exact||((v&&norm(v)==='jine')?'Jiné':'');
 });
 type.addEventListener('change',()=>update(false));
 brand.addEventListener('blur',()=>{
   const input=brand.value.trim();const match=listFor(type.value).find(v=>norm(v)===norm(input));
   if(match)brand.value=match;
 });
 update(true);
}
function setupAll(){setup('tsAppliance','tsQuickBrand','tsQuickBrandOptions');
setup('filterAppliance','filterBrand','tsSearchBrandOptions');
setup('type','brand','tsRequestBrandOptions');
setup('device','brand','tsHeatingSearchBrandOptions');
setup('requestDevice','requestBrand','tsHeatingRequestBrandOptions');
// Recalculate search while the user types a manually entered manufacturer.
const search=document.getElementById('filterBrand');if(search)search.addEventListener('input',()=>search.dispatchEvent(new Event('change',{bubbles:false})));
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',setupAll,{once:true});else setupAll();
})();
