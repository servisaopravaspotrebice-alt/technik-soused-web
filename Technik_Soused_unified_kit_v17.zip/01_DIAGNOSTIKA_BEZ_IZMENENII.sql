-- Technik Soused / Единая диагностика перед коммерческим запуском.
-- SELECT-only: не создаёт, не изменяет и не удаляет данные.
-- Выполняется в Supabase SQL Editor владельцем проекта.
-- Публикует только агрегаты и проверки наличия функций, без клиентских контактов.

WITH checks AS (
 SELECT '01 Объекты'::text AS section, 'Таблица заказов'::text AS check_name,
        CASE WHEN to_regclass('public.ts_orders') IS NOT NULL THEN 'OK' ELSE 'ОШИБКА' END AS result,
        'public.ts_orders'::text AS details
 UNION ALL SELECT '01 Объекты','Профили мастеров',
        CASE WHEN to_regclass('public.ts_technicians') IS NOT NULL THEN 'OK' ELSE 'ОШИБКА' END,
        'public.ts_technicians'
 UNION ALL SELECT '01 Объекты','Подписки мастеров',
        CASE WHEN to_regclass('public.ts_paid_subscriptions') IS NOT NULL THEN 'OK' ELSE 'ОШИБКА' END,
        'public.ts_paid_subscriptions'
 UNION ALL SELECT '01 Объекты','Ручная База',
        CASE WHEN EXISTS (
          SELECT 1 FROM information_schema.columns
          WHERE table_schema='public' AND table_name='ts_orders' AND column_name='admin_hold_at')
        THEN 'OK' ELSE 'ОШИБКА' END, 'Поле admin_hold_at'
 UNION ALL SELECT '01 Объекты','Резервы Premium',
        CASE WHEN to_regclass('ts_private.order_premium_reservations') IS NOT NULL THEN 'OK' ELSE 'ОШИБКА' END,
        'Таблица персональных 15-минутных резервов'
 UNION ALL SELECT '01 Объекты','Изолированная тестовая очередь',
        CASE WHEN to_regclass('ts_private.premium_sandbox_orders') IS NOT NULL THEN 'OK' ELSE 'ОШИБКА' END,
        'Не смешивать с реальными заказами'
 UNION ALL SELECT '02 RPC','Проверка тарифа',
        CASE WHEN to_regprocedure('public.ts_technician_active_tier()') IS NOT NULL THEN 'OK' ELSE 'ОШИБКА' END,
        'Подтверждённая действующая подписка'
 UNION ALL SELECT '02 RPC','Очередь мастеров',
        CASE WHEN to_regprocedure('public.ts_technician_queue_snapshot()') IS NOT NULL THEN 'OK' ELSE 'ОШИБКА' END,
        'Без клиентских контактов'
 UNION ALL SELECT '02 RPC','Личное открытие Premium',
        CASE WHEN to_regprocedure('public.ts_technician_open_premium_order(uuid)') IS NOT NULL THEN 'OK' ELSE 'ОШИБКА' END,
        '15 минут; повторное открытие не продлевает срок'
 UNION ALL SELECT '02 RPC','Отказ Premium',
        CASE WHEN to_regprocedure('public.ts_technician_decline_premium_order(uuid)') IS NOT NULL THEN 'OK' ELSE 'ОШИБКА' END,
        'Освобождение до истечения резерва'
 UNION ALL SELECT '02 RPC','Принятие заказа',
        CASE WHEN to_regprocedure('public.ts_technician_accept_order(uuid)') IS NOT NULL THEN 'OK' ELSE 'ОШИБКА' END,
        'Должна использовать блокировку строки заказа'
 UNION ALL SELECT '02 RPC','Обновление очереди',
        CASE WHEN to_regprocedure('public.ts_advance_queue()') IS NOT NULL THEN 'OK' ELSE 'ОШИБКА' END,
        'Наличие RPC не доказывает наличие задания pg_cron'
 UNION ALL SELECT '02 RPC','Заявка на подписку',
        CASE WHEN to_regprocedure('public.ts_technician_request_subscription(text,text)') IS NOT NULL THEN 'OK' ELSE 'ОШИБКА' END,
        'Создание не подтверждает оплату'
 UNION ALL SELECT '02 RPC','Подтверждение оплаты',
        CASE WHEN to_regprocedure('public.ts_owner_confirm_subscription_payment(uuid,text)') IS NOT NULL THEN 'OK' ELSE 'ОШИБКА' END,
        'Только владелец после проверки денег в банке'
 UNION ALL SELECT '03 Доступ','Анонимам запрещено читать заявки напрямую',
        CASE WHEN NOT has_table_privilege('anon','public.ts_orders','SELECT') THEN 'OK' ELSE 'ПРОВЕРИТЬ' END,
        'Проверка GRANT, не тест внутреннего доступа через другие функции'
 UNION ALL SELECT '03 Доступ','Анонимам запрещено читать подписки напрямую',
        CASE WHEN NOT has_table_privilege('anon','public.ts_paid_subscriptions','SELECT') THEN 'OK' ELSE 'ПРОВЕРИТЬ' END,
        'Оплаченные подписки'
 UNION ALL SELECT '03 Доступ','Анонимам запрещён RPC подтверждения оплаты',
        CASE WHEN NOT has_function_privilege('anon','public.ts_owner_confirm_subscription_payment(uuid,text)','EXECUTE')
        THEN 'OK' ELSE 'ОШИБКА' END,
        'Не заменяет проверку внутри функции'
 UNION ALL SELECT '03 Доступ','RLS на заявках',
        CASE WHEN EXISTS(SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
           WHERE n.nspname='public' AND c.relname='ts_orders' AND c.relkind='r' AND c.relrowsecurity)
        THEN 'OK' ELSE 'ОШИБКА' END,
        'RLS должен быть включён'
 UNION ALL SELECT '03 Доступ','RLS на заявках оплаты',
        CASE WHEN EXISTS(SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
           WHERE n.nspname='public' AND c.relname='ts_subscription_requests' AND c.relkind='r' AND c.relrowsecurity)
        THEN 'OK' ELSE 'ОШИБКА' END,
        'RLS должен быть включён'
 UNION ALL SELECT '04 Данные','Неоплаченные заявки', 'ИНФО',
        (SELECT count(*)::text FROM public.ts_subscription_requests WHERE status='pending')
 UNION ALL SELECT '04 Данные','Активные оплаченные подписки', 'ИНФО',
        (SELECT count(*)::text FROM public.ts_paid_subscriptions
         WHERE valid_from <= now() AND valid_until > now())
 UNION ALL SELECT '04 Данные','Подтверждённые покупки без записи подписки',
        CASE WHEN NOT EXISTS (
          SELECT 1 FROM public.ts_subscription_requests r
          LEFT JOIN public.ts_paid_subscriptions s ON s.source_request_id=r.id
          WHERE r.status='confirmed' AND s.id IS NULL
        ) THEN 'OK' ELSE 'ОШИБКА' END,
        (SELECT count(*)::text FROM public.ts_subscription_requests r
         LEFT JOIN public.ts_paid_subscriptions s ON s.source_request_id=r.id
         WHERE r.status='confirmed' AND s.id IS NULL)
 UNION ALL SELECT '04 Данные','Ручная База', 'ИНФО',
        (SELECT count(*)::text FROM public.ts_orders WHERE admin_hold_at IS NOT NULL AND status='base')
 UNION ALL SELECT '04 Данные','Активные резервы Premium', 'ИНФО',
        (SELECT count(*)::text FROM ts_private.order_premium_reservations
         WHERE outcome='reserved' AND reserved_until>now())
 UNION ALL SELECT '04 Данные','Истекшие резервы с outcome=reserved', 'ИНФО',
        (SELECT count(*)::text FROM ts_private.order_premium_reservations
         WHERE outcome='reserved' AND reserved_until<=now()) || ' (возможна ленивая очистка: доступ определяется временем)'
 UNION ALL SELECT '05 Релиз','Серверная проверка cron', 'ТРЕБУЕТ ТЕСТА',
        'Проверить cron.job и реальное срабатывание, а не только наличие pg_cron'
 UNION ALL SELECT '05 Релиз','Рейтинги реальных клиентов', 'НЕ ПОДКЛЮЧЕНО',
        'Старая страница отзывов использует браузерную демонстрацию'
 UNION ALL SELECT '05 Релиз','Платное продвижение в публичном каталоге', 'НЕ ПОДКЛЮЧЕНО',
        'Не активировать платные размещения без серверного подтверждения оплаты'
 UNION ALL SELECT '05 Релиз','Уведомления и права другого аккаунта', 'ТРЕБУЕТ ТЕСТА',
        'Два разных мастера + диспетчер + анонимный посетитель'
)
SELECT section, check_name, result, details
FROM checks
ORDER BY section, check_name;
